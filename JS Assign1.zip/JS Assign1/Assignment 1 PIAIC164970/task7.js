document.write("<h1>" + "Rules for naming JavaScript variables" + "</h1>" + "<br>" + "<br>");
document.write("Variable names can only contain numbers , $ and _.For example $my_1stVariable" + "<br>" + 
"Variable must begin with letter , $ and _.For example $name , _name , name" + "<br>" + 
"Variable names are sensitive" + "<br>" + 
"Variable names should not be JS Keywords");