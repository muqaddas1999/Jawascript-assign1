var email = "muqaddasahraf3@gmail.com";
alert("My email address is " + email);