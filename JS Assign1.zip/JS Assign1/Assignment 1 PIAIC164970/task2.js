var name = "Muqaddas Ashraf" , age = "21 years old" , course = "Blockchain";
alert(name);
alert(age);
alert(course);