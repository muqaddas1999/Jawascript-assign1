var $ = 10 , sr = 25 , total = 0;
$ = $ * 160;
sr = sr * 55;
total = $ + sr;
document.write("<h1>" + "Currency in PKR" + "</h1>" + "<br>" + "<br>" + "<br>");
document.write("Total currency in PKR " + total);