var age = "21 years old";
alert("I am " + age);