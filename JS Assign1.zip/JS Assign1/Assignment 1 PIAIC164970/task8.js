var num1 = 0 , num2 = 0 , sum = 0;
num1 = +prompt("Enter 1st number to add" , "1st number");
num2 = +prompt("Enter 2nd number to add" , "2nd number");
sum = num1 + num2;
document.write("Sum of " + num1 + " and " + num2 + " is " + sum);