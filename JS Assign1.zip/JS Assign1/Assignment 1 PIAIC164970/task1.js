alert("Welcome to Javascript Land....\n Happy Coding!");

